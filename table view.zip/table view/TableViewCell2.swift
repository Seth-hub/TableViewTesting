//
//  TableViewCell2.swift
//  table view
//
//  Created by Sethumadhav Perumalla on 10/23/16.
//  Copyright © 2016 Sethumadhav Perumalla. All rights reserved.
//

import UIKit

class TableViewCell2: UITableViewCell {
    @IBOutlet weak var mainViewCell2: UIImageView!
    @IBOutlet weak var mainLabelCell: UILabel!
    
}
