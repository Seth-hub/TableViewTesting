//
//  TableViewCEll1TableViewCell.swift
//  table view
//
//  Created by Sethumadhav Perumalla on 10/23/16.
//  Copyright © 2016 Sethumadhav Perumalla. All rights reserved.
//

import UIKit

class TableViewCEll1TableViewCell: UITableViewCell {

    @IBOutlet weak var mainImageCell: UIImageView!
    @IBOutlet weak var mainLabelCell: UILabel!
    
}
