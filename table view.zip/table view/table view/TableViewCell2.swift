//
//  TableViewCell2.swift
//  table view
//
//  Created by Sethumadhav Perumalla on 10/23/16.
//  Copyright © 2016 Sethumadhav Perumalla. All rights reserved.
//

import UIKit

class TableViewCell2: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
