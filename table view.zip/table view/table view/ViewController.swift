//
//  ViewController.swift
//  table view
//
//  Created by Sethumadhav Perumalla on 10/23/16.
//  Copyright © 2016 Sethumadhav Perumalla. All rights reserved.
//

import UIKit
struct <#name#> cellData {
    let cell : Int!
    let text : String!
    let image : Uiimage!
}
class TableViewController: UITableViewController {
    var cellstuff = [cellData]()
    
    override func viewDidLoad() {
        <#code#>
        cellstuff = [cellData(cell : 1)]
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        <#code#>
}

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        <#code#>
}

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        <#code#>
}
